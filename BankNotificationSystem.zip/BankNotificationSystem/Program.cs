﻿namespace BankNotificationSystem;

class Program
{
    static void Main()
    {
        OwnerInfo o1 = new OwnerInfo("Andrew Mark", 1234568, "andrew@gmail.com", "+1828909798");
        OwnerInfo o2 = new OwnerInfo("John Smith", 098765, "john@gmail.com", "+142899934");

        BankService c1 = new BankService(5500, o1);
        BankService c2 = new BankService(7200, o2);
        
        NotificationSubscription s1 = new NotificationSubscription(c1, NotificationOptions.Email);
        NotificationSubscription s2 = new NotificationSubscription(c2, NotificationOptions.Phone);
        
        Console.WriteLine();
        c1.Deposit(4500);
        Console.WriteLine();
        c2.Withdraw(2200);
        Console.WriteLine();
    }
}