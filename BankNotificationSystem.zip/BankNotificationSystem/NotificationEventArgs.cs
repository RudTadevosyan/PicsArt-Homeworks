﻿namespace BankNotificationSystem;

public class NotificationEventArgs: EventArgs
{
    public NotificationModule Notification;
    public OwnerInfo Owner;

    public NotificationEventArgs(NotificationModule notification, OwnerInfo owner)
    {
        Notification = notification;
        Owner = owner;
    }
    
}