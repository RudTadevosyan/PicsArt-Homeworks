﻿namespace BankNotificationSystem;

public class EmailSender:INotificationSender
{
    public void SendNotification(object? sender, NotificationEventArgs e)
    {
        Console.WriteLine($"Sending notification to {e.Owner.Email} Email\n");
        Console.WriteLine(e.Notification.ToString());
    }
}