﻿namespace BankNotificationSystem;

public class BankService: ClientAccount
{
    public BankService(decimal balance, OwnerInfo owner) : base(balance, owner)
    { }

    public void Deposit(decimal amount)
    {
        if (amount <= 0)
        {
            throw new ArgumentException("Amount cannot be negative or 0");
        }
        
        Balance += amount;
    }

    public void Withdraw(decimal amount)
    {
        if (amount <= 0)
        {
            throw new ArgumentException("Amount cannot be negative or 0");
        }

        if (amount > Balance)
        {
            throw new ArgumentException("Amount cannot be greater than balance");
        }
        
        Balance -= amount;
    }
    
}