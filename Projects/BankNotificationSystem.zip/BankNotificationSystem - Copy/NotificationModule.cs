﻿namespace BankNotificationSystem;

public class NotificationModule
{
    public string Title { get; private set; }
    public string Message { get; private set; }
    public OwnerInfo Receiver { get; private set; }

    public NotificationModule(string title, string message, OwnerInfo owner)
    {
        Title = title;
        Message = message;
        Receiver = owner;
    }

    public override string ToString()
    {
        return $"{Title}\n***************\n{Message}\n***************\n{Receiver.FullName}";
    }
}