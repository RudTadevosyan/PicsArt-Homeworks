﻿namespace BankNotificationSystem;

public enum NotificationOptions
{
    Email,
    Phone
}