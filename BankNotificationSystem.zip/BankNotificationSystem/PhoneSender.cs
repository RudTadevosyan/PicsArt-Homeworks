﻿namespace BankNotificationSystem;

public class PhoneSender:INotificationSender
{
    public void SendNotification(object? sender, NotificationEventArgs e)
    {
        Console.WriteLine($"Sending notification to {e.Owner.Phone} PhoneNumber\n");
        Console.WriteLine(e.Notification.ToString());
    }
}