﻿namespace BankNotificationSystem;

public interface INotificationSender
{
    void SendNotification(object? sender, NotificationEventArgs e);
}