﻿namespace BankNotificationSystem;
public class NotificationSubscription
{
    private ClientAccount _account;
    private INotificationSender? _sender;
    public NotificationSubscription(ClientAccount account, NotificationOptions option)
    {
        _account = account;
        if (option == NotificationOptions.Email)
        {
            _sender = new EmailSender();
            account.NotificationMethods.BalanceChanged += _sender.SendNotification;
        }
        else if (option == NotificationOptions.Phone)
        {
            _sender = new PhoneSender();
            account.NotificationMethods.BalanceChanged += _sender.SendNotification;
        }
    }
    
    
}