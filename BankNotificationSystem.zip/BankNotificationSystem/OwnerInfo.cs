﻿namespace BankNotificationSystem;

public class OwnerInfo
{
    public string FullName { get; private set; }
    public long Id { get; private set; }
    public string Email { get; private set; }
    public string Phone { get; private set; }

    public OwnerInfo(string fullName, long id, string email, string phone)
    {
        FullName = fullName;
        Id = id;
        Email = email;
        Phone = phone;
    }
}