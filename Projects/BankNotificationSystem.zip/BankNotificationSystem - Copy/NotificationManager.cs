﻿namespace BankNotificationSystem;

public class NotificationManager
{
    public event EventHandler<NotificationEventArgs>? BalanceChanged;

    private OwnerInfo _owner;

    public NotificationManager(OwnerInfo owner)
    {
        _owner = owner;
    }

    public void OnBalanceChanged(NotificationModule notify)
    {
        BalanceChanged?.Invoke(this, new NotificationEventArgs(notify, _owner));
    }

    public NotificationModule PrepareNotification(decimal oldValue, decimal newValue)
    {
        string title = "";
        string message = "";
        if (newValue > oldValue)
        {
            var deposit = newValue - oldValue;
            title = "Balance Deposit";
            message = $"You received {deposit}$\nYour new balance is {newValue}$";
        }
        else
        {
            var withdraw = oldValue - newValue;
            title = "Balance Withdraw";
            message = $"You sent {withdraw}$\nYour new balance is {newValue}$";
        }

        return new NotificationModule(title, message, _owner);
    }
}