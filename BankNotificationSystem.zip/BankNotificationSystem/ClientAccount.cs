﻿namespace BankNotificationSystem;

public class ClientAccount
{
    public OwnerInfo Owner { get; private set; }
    public NotificationManager NotificationMethods { get; private set; }
    
    private decimal _balance;
    public decimal Balance
    {
        get => _balance;
        protected set
        {
            if(value == _balance) return;
            
            decimal oldValue = _balance;
            _balance = value;
            
            var notification = NotificationMethods.PrepareNotification(oldValue, _balance);
            NotificationMethods.OnBalanceChanged(notification);
        }
    }

    public ClientAccount(decimal balance, OwnerInfo owner)
    {
        Owner = owner;
        _balance = balance;
        NotificationMethods = new NotificationManager(owner);
    }
    
    
}